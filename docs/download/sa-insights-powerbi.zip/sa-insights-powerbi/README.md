# SA Insights — Power BI model

A ready-to-import semantic model for the SA Insights South African macro data.
Generated 08 November 2026 from the same definitions used by the
[Apache Ossie](../semantic/sa_insights.ossie.yaml) model.

## What is in this bundle

| File | Rows | Purpose |
|------|------|---------|
| `dim_indicator.csv` | 33 | One row per indicator: label, category, unit, frequency, provider. |
| `dim_date.csv` | 855 | Monthly calendar: year, quarter, month, sort keys. |
| `fact_observation.csv` | 8,119 | Measured values. `series_key` + `date_key` + `value`. |
| `fact_forecast.csv` | 222 | Forecasts with an 80% interval and the model that produced them. |
| `sa_insights.model.bim` | — | Tabular model: tables, relationships, hierarchy and measures. |
| `measures.dax` | 17 | The same measures as readable DAX. |

## Why one long fact table

The Ossie document uses one dataset per indicator. In Power BI that would mean
29 near-identical tables and a field list nobody can navigate. This export
instead uses a single `fact_observation` table with `series_key` as the foreign
key, which gives you one compact model and natural slicers. No information is
lost — every indicator is still individually selectable.

## Option A — open the model definition (fastest)

1. Open **Tabular Editor 2** (free) or Power BI Desktop with the *Tabular
   Editor 3* external tool installed.
2. Open `sa_insights.model.bim`.
3. In the model, edit the `DataFolder` expression to point at this folder.
4. Click **Process** → **Process Full** to load the CSVs.
5. Save as a Power BI file, or deploy to a workspace.

## Option B — import the CSVs manually

1. Extract this bundle to a folder.
2. Power BI Desktop → **Get data** → **Text/CSV**.
3. Import all four CSVs. Choose *Transform Data* and confirm `date` is a Date
   type and `value` / `forecast` / `lower_80` / `upper_80` are Decimal Number.
4. In Model view, create these relationships:

   | From | To | Cardinality |
   |------|-----|-------------|
   | `fact_observation[series_key]` | `dim_indicator[series_key]` | many-to-one |
   | `fact_observation[date_key]` | `dim_date[date_key]` | many-to-one |
   | `fact_forecast[series_key]` | `dim_indicator[series_key]` | many-to-one |
   | `fact_forecast[date_key]` | `dim_date[date_key]` | many-to-one |

5. Select `dim_date`, then **Table tools → Mark as date table**, column `date`.
   This is required by the year-on-year measures.
6. Open `measures.dax` and paste each measure into the table named in its
   comment.

## The measures

| Measure | What it answers |
|---------|-----------------|
| `Latest Value` | The most recent published figure for the selection. |
| `Latest Period` | What date that figure refers to. |
| `Previous Value`, `Change`, `Change %` | Movement since the prior observation. |
| `Value YoY Change`, `Value YoY %` | Movement versus a year earlier. |
| `Average Value`, `Volatility` | Central tendency and dispersion. |
| `Coverage Years` | How much history is behind the number. |
| `Indicator Count` | How many indicators are in scope. |
| `Real Policy Rate` | Repo rate less CPI — is policy tight in real terms? |
| `Credit Spread` | Lending rate less repo rate. |
| `Trade Balance (US$ m)` | Exports less imports. |
| `Forecast End Value` | Where the projection lands at the horizon. |
| `Forecast Interval Width` | How uncertain that projection is. |

Watch out for `Latest Value` in a table visual: it returns a single value per
indicator, so always put `dim_indicator[Indicator]` on rows. Slicing by
`dim_date[year]` changes which observation counts as "latest" within that year,
which is usually what you want.

## Suggested starting report

- **Card** — `Latest Value` filtered to one indicator, with `Latest Period` as
  the subtitle.
- **Line chart** — `dim_date[date]` on the axis, `Average Value` as values,
  `dim_indicator[Indicator]` as the legend.
- **Table** — `dim_indicator[Indicator]` on rows, with `Latest Value`,
  `Value YoY %` and `Coverage Years`.
- **Slicers** — `dim_indicator[Category]`, `dim_indicator[Frequency]`,
  `dim_date[year]`.

## Caveats

Frequency differs by indicator: CPI and the repo rate are monthly, real GDP is
quarterly, unemployment and the debt ratio are annual. Power BI will happily
plot them on the same axis, but that can imply precision that does not exist.
Filter by `dim_indicator[Frequency]` when mixing indicators, and always show
`Latest Period` alongside a headline number so nobody mistakes an annual figure
for a current one.

Forecasts are statistical extrapolations chosen by a rolling-origin backtest,
not predictions of policy or shocks. `fact_forecast[model]` records which model
won for each series, so the provenance travels with the data.
